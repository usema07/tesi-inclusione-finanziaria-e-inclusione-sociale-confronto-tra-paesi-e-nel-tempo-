
# 1) LIBRERIE

packages <- c(
  "dplyr", "tidyr", "ggplot2", "readxl", "readr",
  "corrplot", "car", "lmtest", "sandwich","plm"
)

installed <- rownames(installed.packages())

for (p in packages) {
  if (!(p %in% installed)) {
    install.packages(p)
  }
}

library(dplyr)
library(tidyr)
library(ggplot2)
library(readxl)
library(readr)
library(corrplot)
library(car)
library(lmtest)
library(sandwich)
library(plm)

# 2) IMPORTAZIONE DATASET
df <- read_excel("GlobalFindexDatabase2025.xlsx", sheet = "Data")


# 3) Nel file Excel la seconda riga contiene i nomi completi delle variabili
# la uso quindi come intestazione del dataset al posto dei codici tecnici

new_names <- as.character(df[1, ])
new_names[new_names == "" | is.na(new_names)] <-
  names(df)[new_names == "" | is.na(new_names)]
names(df) <- new_names
df <- df[-1, ]


# 4) VARIABILI DEL MODELLO

y_var <- "Saved for old age (%, age 15+)"

x_vars <- c(
  "Saved at a bank or similar financial institution or using a mobile money account (%, age 15+)",
  "Own a debit card (%, age 15+)",
  "Made or received a digital payment (%, age 15+)",
  "Coming up with emergency funds in 30 days: possible (%, age 15+)"
)

vars_model <- c(y_var, x_vars)
vars_compare <- vars_model
years_use <- c(2014, 2017, 2021, 2024)


# 5) Controllo che tutte le variabili necessarie siano presenti nel dataset
required_cols <- c(
  "Economy",
  "Year",
  "Demographic group",
  "Demographic sub-group",
  "Income group",
  vars_model
)

missing_cols <- setdiff(required_cols, names(df))

if (length(missing_cols) > 0) {
  stop(
    paste(
      "ERRORE: mancano queste colonne nel dataset:\n-",
      paste(missing_cols, collapse = "\n- ")
    )
  )
}


# 6a) PULIZIA DATASET - TENIAMO SOLO ALL / ALL

df0 <- df %>%
  select(all_of(c(
    "Economy",
    "Year",
    "Demographic group",
    "Demographic sub-group",
    "Income group",
    vars_model
  ))) %>%
  mutate(
    Year = suppressWarnings(as.integer(as.character(Year))),
    across(
      all_of(vars_model),
      ~ suppressWarnings(parse_number(as.character(.)))
    ),
    `Income group` = trimws(as.character(`Income group`))
  ) %>%
  filter(
    Year %in% years_use,
    `Demographic group` == "all",
    `Demographic sub-group` == "all"
  )

if (nrow(df0) == 0) {
  stop("ERRORE: nessuna osservazione negli anni selezionati.")
}

cat("\n====================\n")
cat("DATASET PRIMA DELLA PULIZIA\n")
cat("====================\n")
cat("Osservazioni in df0:", nrow(df0), "\n")
cat("Paesi in df0:", n_distinct(df0$Economy), "\n")



# 6b) PULIZIA AGGIUNTIVA


# a) Rimuovo le osservazioni con NA nelle variabili del modello
df_clean <- df0 %>%
  select(Economy, Year, `Income group`, all_of(vars_model)) %>%
  na.omit()

cat("\nDopo na.omit:", nrow(df_clean), "osservazioni\n")

# b) Rimuovo raggruppamenti regionali
aggregati <- c(
  "Developing economies", "Developed economies",
  "East Asia & Pacific", "East Asia and Pacific",
  "Europe & Central Asia", "Europe and Central Asia",
  "Latin America & Caribbean", "Latin America and the Caribbean",
  "Middle East & North Africa", "Middle East and North Africa",
  "South Asia", "Sub-Saharan Africa",
  "High income", "Low income",
  "Lower middle income", "Upper middle income",
  "Low & middle income", "Low and middle income",
  "World", "Euro area", "European Union",
  "Arab World", "Central Europe and the Baltics",
  "East Asia & Pacific (excluding high income)",
  "Europe & Central Asia (excluding high income)",
  "Latin America & Caribbean (excluding high income)",
  "Middle East & North Africa (excluding high income)",
  "South Asia (IDA & IBRD)",
  "Sub-Saharan Africa (excluding high income)",
  "OECD members", "Small states",
  "Fragile and conflict affected situations",
  "Heavily indebted poor countries (HIPC)",
  "IDA total", "IDA blend", "IDA only",
  "IBRD only", "Least developed countries: UN classification",
  "North America", "Pacific island small states",
  "Caribbean small states", "Other small states"
)

df_clean <- df_clean %>%
  filter(!(Economy %in% aggregati))

cat("Dopo rimozione aggregati:", nrow(df_clean), "osservazioni,",
    n_distinct(df_clean$Economy), "paesi\n")

# c) Rimuovo l'osservazione anomala: Marocco 2024 con old_age_saving = 0
df_clean <- df_clean %>%
  filter(!(Economy == "Morocco" & Year == 2024 &
             `Saved for old age (%, age 15+)` == 0))

cat("Dopo rimozione Morocco 2024:", nrow(df_clean), "osservazioni\n")

# d) Rimuovo paesi con una sola osservazione (non utili per il panel)
paesi_multi <- df_clean %>%
  count(Economy) %>%
  filter(n >= 2) %>%
  pull(Economy)

df_clean <- df_clean %>%
  filter(Economy %in% paesi_multi)

cat("Dopo rimozione paesi con 1 sola oss:", nrow(df_clean), "osservazioni,",
    n_distinct(df_clean$Economy), "paesi\n")

# e) Imposto Income group come fattore con riferimento Low income
df_clean$`Income group` <- relevel(
  as.factor(df_clean$`Income group`),
  ref = "Low income"
)

cat("\n====================\n")
cat("DATASET FINALE\n")
cat("====================\n")
cat("Osservazioni:", nrow(df_clean), "\n")
cat("Paesi:", n_distinct(df_clean$Economy), "\n")
cat("Anni:", paste(sort(unique(df_clean$Year)), collapse = ", "), "\n")
print(table(df_clean$`Income group`, useNA = "ifany"))



# 7) CONTROLLO STRUTTURA DATASET FINALE


cat("\n====================\n")
cat("CONTROLLO DATASET FINALE\n")
cat("====================\n")

cat("\nOsservazioni per anno:\n")
print(table(df_clean$Year))

dup_check <- df_clean %>%
  count(Economy, Year) %>%
  filter(n > 1)

cat("\nControllo duplicati paese-anno:\n")
if (nrow(dup_check) == 0) {
  cat("Nessun duplicato: ogni paese-anno compare una sola volta.\n")
} else {
  print(dup_check)
}

cat("\nPaesi per numero di osservazioni:\n")
print(table(table(df_clean$Economy)))


# 8) Funzioni safe per statistiche descrittive

safe_mean <- function(x) {
  if (all(is.na(x))) NA else mean(x, na.rm = TRUE)
}

safe_sd <- function(x) {
  if (sum(!is.na(x)) <= 1) NA else sd(x, na.rm = TRUE)
}

safe_min <- function(x) {
  if (all(is.na(x))) NA else min(x, na.rm = TRUE)
}

safe_q1 <- function(x) {
  if (all(is.na(x))) NA else as.numeric(quantile(x, 0.25, na.rm = TRUE))
}

safe_median <- function(x) {
  if (all(is.na(x))) NA else median(x, na.rm = TRUE)
}

safe_q3 <- function(x) {
  if (all(is.na(x))) NA else as.numeric(quantile(x, 0.75, na.rm = TRUE))
}

safe_max <- function(x) {
  if (all(is.na(x))) NA else max(x, na.rm = TRUE)
}


# 9) Informazioni di base sul dataset

cat("\n====================\n")
cat("DESCRIZIONE DATASET\n")
cat("====================\n")

cat("\nAnni presenti nel campione:\n")
print(sort(unique(df_clean$Year)))

cat("\nNumero di paesi:\n")
print(n_distinct(df_clean$Economy))

cat("\nNumero totale osservazioni:\n")
print(nrow(df_clean))


# 10) STATISTICHE DESCRITTIVE PER ANNO
# ORA TUTTE LE ANALISI SI FANNO SU df_clean (dataset finale pulito)

summary_year <- df_clean %>%
  pivot_longer(
    cols = all_of(vars_model),
    names_to = "Variable",
    values_to = "Value"
  ) %>%
  group_by(Year, Variable) %>%
  summarise(
    N = sum(!is.na(Value)),
    Mean = safe_mean(Value),
    SD = safe_sd(Value),
    Min = safe_min(Value),
    Q1 = safe_q1(Value),
    Median = safe_median(Value),
    Q3 = safe_q3(Value),
    Max = safe_max(Value),
    .groups = "drop"
  )

cat("\n====================\n")
cat("STATISTICHE DESCRITTIVE\n")
cat("====================\n")
print(summary_year, n = nrow(summary_year))


while (!is.null(dev.list())) dev.off()  # Sblocca il pannello Plots


# Nomi brevi per heatmap e grafici
short_names_model <- c(
  "Old age saving",
  "Formal saving",
  "Debit card",
  "Digital payment",
  "Emergency funds"
)


# 11) FILTRO CAMPIONE BILANCIATO (paesi presenti 2014-2024)

paesi_entrambi <- df_clean %>%
  filter(Year %in% c(2014, 2024)) %>%
  group_by(Economy) %>%
  filter(all(c(2014, 2024) %in% Year)) %>%
  pull(Economy) %>%
  unique()

df_balanced <- df_clean %>% filter(Economy %in% paesi_entrambi)


# 12) trend NEL TEMPO DELLE VARIABILI 

summary_year <- df_balanced %>%
  pivot_longer(
    cols = all_of(vars_model),
    names_to = "Variable",
    values_to = "Value"
  ) %>%
  group_by(Year, Variable) %>%
  summarise(Mean = mean(Value, na.rm = TRUE), .groups = "drop") %>%
  mutate(Variable = case_when(
    grepl("old age", Variable) ~ "Old age saving",
    grepl("bank or similar", Variable) ~ "Formal saving",
    grepl("debit card", Variable) ~ "Debit card",
    grepl("digital payment", Variable) ~ "Digital payment",
    grepl("emergency funds", Variable) ~ "Emergency funds",
    TRUE ~ Variable
  ))

p_trend <- ggplot(summary_year, aes(x = Year, y = Mean, group = Variable)) +
  geom_line(linewidth = 1, color = "darkred") +
  geom_point(size = 2.2, color = "darkred") +
  facet_wrap(~Variable, scales = "free_y") +
  scale_x_continuous(breaks = years_use) +
  labs(
    title = "Trend globali delle variabili nel tempo",
    x = "Anno",
    y = "Media"
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    strip.text = element_text(size = 11)
  )

print(p_trend)
ggsave("fig_trend_variabili.png", plot = p_trend, width = 14, height = 9, dpi = 300)


# 13) CONFRONTO 2014 vs 2024 (Boxplot)

df_compare <- df_balanced %>%
  filter(Year %in% c(2014, 2024)) %>%
  select(all_of(c("Economy", "Year", vars_compare))) %>%
  pivot_longer(
    cols = all_of(vars_compare),
    names_to = "Variable",
    values_to = "Value"
  ) %>%
  filter(!is.na(Value)) %>%
  mutate(Variable = case_when(
    grepl("old age", Variable) ~ "Old age saving",
    grepl("bank or similar", Variable) ~ "Formal saving",
    grepl("debit card", Variable) ~ "Debit card",
    grepl("digital payment", Variable) ~ "Digital payment",
    grepl("emergency funds", Variable) ~ "Emergency funds",
    TRUE ~ Variable
  ))

summary_compare <- df_compare %>%
  group_by(Year, Variable) %>%
  summarise(
    N = n(),
    Mean = mean(Value),
    SD = sd(Value),
    Median = median(Value),
    Min = min(Value),
    Max = max(Value),
    .groups = "drop"
  )

cat("\n====================\n")
cat("CONFRONTO 2014 vs 2024\n")
cat("====================\n")
print(summary_compare, n = nrow(summary_compare))

p_boxplot <- ggplot(df_compare, aes(x = factor(Year), y = Value, fill = factor(Year))) +
  geom_boxplot(outlier.alpha = 0.25, width = 0.6) +
  facet_wrap(~Variable, scales = "free_y") +
  scale_fill_manual(values = c("2014" = "#4393C3", "2024" = "#D6604D")) +
  labs(
    title = "Distribuzione variabili: 2014 vs 2024",
    x = "Anno",
    y = "Valore"
  ) +
  theme_minimal(base_size = 16) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 18),
    strip.text = element_text(size = 14, face = "bold"),
    axis.text = element_text(size = 12),
    axis.title = element_text(size = 14),
    legend.position = "none",
    panel.spacing = unit(1.5, "lines")
  )

print(p_boxplot)
ggsave("fig_boxplot_2014_2024.png", plot = p_boxplot, width = 14, height = 10, dpi = 300)


# 14) MATRICI DI CORRELAZIONE E HEATMAP (Bilanciato)

df_2014 <- df_balanced %>% filter(Year == 2014) %>% select(all_of(vars_compare))
df_2024 <- df_balanced %>% filter(Year == 2024) %>% select(all_of(vars_compare))

cor_2014 <- cor(df_2014, use = "pairwise.complete.obs")
cor_2024 <- cor(df_2024, use = "pairwise.complete.obs")
delta_cor <- cor_2024 - cor_2014

colnames(cor_2014) <- rownames(cor_2014) <- short_names_model
colnames(cor_2024) <- rownames(cor_2024) <- short_names_model
colnames(delta_cor) <- rownames(delta_cor) <- short_names_model

# 15)---- Heatmap 2014 ----
png("fig_heatmap_2014.png", width=3200, height=2800, res=300)
par(mar=c(2,2,4,2))
corrplot(
  cor_2014, method="color", type="upper", diag=FALSE,
  addCoef.col="black", number.cex=1.4, tl.col="black", tl.cex=1.4, tl.srt=25,
  cl.cex=1.2, col=colorRampPalette(c("#B2182B","#F7F7F7","#2166AC"))(200),
  title="Heatmap correlazioni - 2014"
)
dev.off()

# ---- Heatmap 2024 ----
png("fig_heatmap_2024.png", width=3200, height=2800, res=300)
par(mar=c(2,2,4,2))
corrplot(
  cor_2024, method="color", type="upper", diag=FALSE,
  addCoef.col="black", number.cex=1.4, tl.col="black", tl.cex=1.4, tl.srt=25,
  cl.cex=1.2, col=colorRampPalette(c("#B2182B","#F7F7F7","#2166AC"))(200),
  title="Heatmap correlazioni - 2024"
)
dev.off()

# 16) DIFFERENZA CORRELAZIONI NELLA heatmap (2014 - 2024) 
png("fig_heatmap_differenza.png", width=3200, height=2800, res=300)
par(mar=c(2,2,4,2))
corrplot(
  delta_cor, is.corr=FALSE, method="color", type="upper", diag=FALSE,
  addCoef.col="black", number.cex=1.4, tl.col="black", tl.cex=1.4, tl.srt=25,
  cl.cex=1.2, col=colorRampPalette(c("#B2182B","#F7F7F7","#2166AC"))(200),
  title="Differenza correlazioni: 2024 - 2014"
)
dev.off()

#  Mostra heatmap a schermo 
corrplot(cor_2014, method="color", type="upper", diag=FALSE,
         addCoef.col="black", number.cex=0.75, tl.col="black", tl.cex=0.8, tl.srt=20,
         col=colorRampPalette(c("#B2182B","#F7F7F7","#2166AC"))(200),
         title="Heatmap correlazioni - 2014", mar=c(1,1,2,1))

corrplot(cor_2024, method="color", type="upper", diag=FALSE,
         addCoef.col="black", number.cex=0.75, tl.col="black", tl.cex=0.8, tl.srt=20,
         col=colorRampPalette(c("#B2182B","#F7F7F7","#2166AC"))(200),
         title="Heatmap correlazioni - 2024", mar=c(1,1,2,1))

corrplot(delta_cor, is.corr=FALSE, method="color", type="upper", diag=FALSE,
         addCoef.col="black", number.cex=0.75, tl.col="black", tl.cex=0.8, tl.srt=20,
         col=colorRampPalette(c("#B2182B","#F7F7F7","#2166AC"))(200),
         title="Differenza correlazioni: 2024 - 2014", mar=c(1,1,2,1))


# 17) FOCUS SU UN SOTTOGRUPPO DI PAESI

countries_focus <- c(
  "Germany", "France", "Italy", "Spain",
   "United States", "China"
)

df_geo <- df_clean %>%
  filter(Economy %in% countries_focus)


# 18) GRAFICI A LINEE PER PAESE

for (v in vars_model) {
  file_name <- paste0("fig_paese_", gsub("[^a-zA-Z]", "_", v), ".png")

  p <- ggplot(
    df_geo %>% filter(!is.na(.data[[v]])),
    aes(x = Year, y = .data[[v]], color = Economy, group = Economy)
  ) +
    geom_line(linewidth = 1) +
    geom_point(size = 2) +
    scale_x_continuous(breaks = years_use) +
    labs(
      title = v,
      x = "Anno",
      y = "Percentuale",
      color = "Paese"
    ) +
    theme_minimal(base_size = 14) +
    theme(
      plot.title = element_text(hjust = 0.5, face = "bold", size = 13),
      legend.position = "right",
      legend.text = element_text(size = 10),
      panel.grid.major = element_line(color = "grey80"),
      panel.grid.minor = element_blank()
    )

  print(p)
  ggsave(file_name, plot = p, width = 14, height = 8, dpi = 300)
}


# 19) TREND MEDIO DEI PAESI SELEZIONATI

df_geo_summary <- df_geo %>%
  pivot_longer(
    cols = all_of(vars_model),
    names_to = "Variable",
    values_to = "Value"
  ) %>%
  group_by(Year, Variable) %>%
  summarise(
    Mean = mean(Value, na.rm = TRUE),
    Min = min(Value, na.rm = TRUE),
    Max = max(Value, na.rm = TRUE),
    .groups = "drop"
  )

p_geo_trend <- ggplot(df_geo_summary, aes(x = Year, y = Mean)) +
  geom_ribbon(aes(ymin = Min, ymax = Max), alpha = 0.2) +
  geom_line(linewidth = 1) +
  geom_point(size = 2) +
  facet_wrap(~Variable, scales = "free_y") +
  scale_x_continuous(breaks = years_use) +
  labs(
    title = "Trend medio dei paesi selezionati",
    x = "Anno",
    y = "Valore medio"
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    strip.text = element_text(size = 11)
  )

print(p_geo_trend)
ggsave("fig_trend_paesi_selezionati.png", plot = p_geo_trend, width = 14, height = 9, dpi = 300)



# 20) PREPARAZIONE DATASET PANEL CON NOMI SEMPLICI
# Usa lo stesso df_clean gia pulito


panel_data <- df_clean %>%
  rename(
    old_age_saving = all_of(y_var),
    formal_saving = all_of(x_vars[1]),
    debit_card = all_of(x_vars[2]),
    digital_payment = all_of(x_vars[3]),
    emergency_funds = all_of(x_vars[4])
  )

pdata <- pdata.frame(panel_data, index = c("Economy", "Year"))

cat("\n====================\n")
cat("DATASET PANEL\n")
cat("====================\n")
cat("Osservazioni:", nrow(pdata), "\n")
cat("Paesi:", length(unique(pdata$Economy)), "\n")
cat("Anni:", paste(sort(unique(as.integer(as.character(pdata$Year)))), collapse = ", "), "\n")



# 21) MODELLO POOLED OLS CON INCOME GROUP E EFFETTI TEMPORALI


pool_model <- plm(
  old_age_saving ~ formal_saving + debit_card + digital_payment + emergency_funds +
    `Income.group` + factor(Year),
  data = pdata,
  model = "pooling"
)

cat("\n====================\n")
cat("MODELLO POOLED OLS (con Income group + factor(Year))\n")
cat("====================\n")
print(summary(pool_model))

cat("\n====================\n")
cat("POOLED OLS CON ERRORI ROBUSTI\n")
cat("====================\n")
print(coeftest(pool_model, vcov = vcovHC(pool_model, type = "HC1")))



# 22) MODELLO FIXED EFFECTS CON EFFETTI TEMPORALI


fe_model <- plm(
  old_age_saving ~ formal_saving + debit_card + digital_payment + emergency_funds + factor(Year),
  data = pdata,
  model = "within"
)

cat("\n====================\n")
cat("MODELLO FIXED EFFECTS (con factor(Year))\n")
cat("====================\n")
print(summary(fe_model))

cat("\n====================\n")
cat("FE CON ERRORI ROBUSTI (Arellano)\n")
cat("====================\n")
print(coeftest(fe_model, vcov = vcovHC(fe_model, method = "arellano", type = "HC1")))



# 23) MODELLO RANDOM EFFECTS CON EFFETTI TEMPORALI


re_model <- plm(
  old_age_saving ~ formal_saving + debit_card + digital_payment + emergency_funds + factor(Year),
  data = pdata,
  model = "random"
)

cat("\n====================\n")
cat("MODELLO RANDOM EFFECTS (con factor(Year))\n")
cat("====================\n")
print(summary(re_model))

cat("\n====================\n")
cat("RE CON ERRORI ROBUSTI (Arellano)\n")
cat("====================\n")
print(coeftest(re_model, vcov = vcovHC(re_model, method = "arellano", type = "HC1")))



# 24) TEST DI SCELTA DEL MODELLO PANEL


# Per i test servono modelli senza factor(Year) per il confronto FE vs Pooled
pool_base <- plm(
  old_age_saving ~ formal_saving + debit_card + digital_payment + emergency_funds,
  data = pdata,
  model = "pooling"
)

fe_base <- plm(
  old_age_saving ~ formal_saving + debit_card + digital_payment + emergency_funds,
  data = pdata,
  model = "within"
)

cat("\n====================\n")
cat("TEST F: FIXED EFFECTS VS POOLED OLS\n")
cat("====================\n")
print(pFtest(fe_base, pool_base))

cat("\n====================\n")
cat("TEST BREUSCH-PAGAN: RANDOM EFFECTS VS POOLED OLS\n")
cat("====================\n")
print(plmtest(pool_base, type = "bp"))

cat("\n====================\n")
cat("TEST DI HAUSMAN: FIXED EFFECTS VS RANDOM EFFECTS\n")
cat("====================\n")
print(phtest(fe_model, re_model))

# Test F sugli effetti temporali: H0 = gli effetti anno non sono necessari
cat("\n====================\n")
cat("TEST F: EFFETTI TEMPORALI SIGNIFICATIVI?\n")
cat("====================\n")
print(pFtest(fe_model, fe_base))



# 25) DIAGNOSTICA OLS (su dati pooled per confronto)


model_ols <- lm(
  old_age_saving ~ formal_saving + debit_card + digital_payment + emergency_funds,
  data = panel_data
)

cat("\n====================\n")
cat("REGRESSIONE OLS BASE\n")
cat("====================\n")
print(summary(model_ols))

cat("\n====================\n")
cat("VIF - MODELLO OLS\n")
cat("====================\n")
vif_values <- vif(model_ols)
print(vif_values)

cat("\n====================\n")
cat("BREUSCH-PAGAN TEST\n")
cat("====================\n")
bp_test <- bptest(model_ols)
print(bp_test)

cat("\n====================\n")
cat("SHAPIRO-WILK TEST\n")
cat("====================\n")
if (nrow(panel_data) <= 5000) {
  shapiro_res <- shapiro.test(residuals(model_ols))
  print(shapiro_res)
} else {
  cat("Campione molto grande: Shapiro-Wilk non eseguito.\n")
}

cat("\n====================\n")
cat("DURBIN-WATSON TEST\n")
cat("====================\n")
dw_res <- dwtest(model_ols)
print(dw_res)

cat("\n====================\n")
cat("ERRORI STANDARD ROBUSTI - OLS\n")
cat("====================\n")
print(coeftest(model_ols, vcov = vcovHC(model_ols, type = "HC1")))

# Grafici diagnostici OLS
png("fig_diagnostica_ols.png", width = 3200, height = 2400, res = 300)
par(mfrow = c(2, 2))
plot(model_ols)
par(mfrow = c(1, 1))
dev.off()

par(mfrow = c(2, 2))
plot(model_ols)
par(mfrow = c(1, 1))

# Cook's distance
cook_vals <- cooks.distance(model_ols)
cook_threshold <- 4 / nrow(panel_data)
influential_obs <- which(cook_vals > cook_threshold)

cat("\n====================\n")
cat("COOK'S DISTANCE\n")
cat("====================\n")
cat("\nSoglia Cook's distance:", round(cook_threshold, 5), "\n")
cat("Numero osservazioni influenti:", length(influential_obs), "\n")

png("fig_cook_distance.png", width = 2400, height = 1600, res = 300)
plot(
  cook_vals,
  type = "h",
  main = "Cook's Distance",
  xlab = "Osservazione",
  ylab = "Cook's distance",
  cex.main = 1.3,
  cex.lab = 1.1
)
abline(h = cook_threshold, col = "red", lty = 2, lwd = 2)
dev.off()

plot(
  cook_vals,
  type = "h",
  main = "Cook's Distance",
  xlab = "Osservazione",
  ylab = "Cook's distance"
)
abline(h = cook_threshold, col = "red", lty = 2)



# 26) RIEPILOGO DIAGNOSTICA


diagnostic_summary <- data.frame(
  Check = c(
    "Max VIF",
    "Breusch-Pagan p-value",
    "Durbin-Watson p-value",
    "Numero osservazioni influenti"
  ),
  Value = c(
    max(vif_values),
    bp_test$p.value,
    dw_res$p.value,
    length(influential_obs)
  )
)

cat("\n====================\n")
cat("RIEPILOGO CONTROLLI DIAGNOSTICI\n")
cat("====================\n")
print(diagnostic_summary)



# 27) MODELLI FE SINGOLI CON EFFETTI TEMPORALI


# Modello 1: formal_saving
fe_single1 <- plm(
  old_age_saving ~ formal_saving + factor(Year),
  data = pdata,
  model = "within"
)

cat("\n====================\n")
cat("FE SINGOLO: FORMAL SAVING + factor(Year)\n")
cat("====================\n")
print(summary(fe_single1))
cat("\nErrori robusti:\n")
print(coeftest(fe_single1, vcov = vcovHC(fe_single1, method = "arellano", type = "HC1")))


# Modello 2: debit_card
fe_single2 <- plm(
  old_age_saving ~ debit_card + factor(Year),
  data = pdata,
  model = "within"
)

cat("\n====================\n")
cat("FE SINGOLO: DEBIT CARD + factor(Year)\n")
cat("====================\n")
print(summary(fe_single2))
cat("\nErrori robusti:\n")
print(coeftest(fe_single2, vcov = vcovHC(fe_single2, method = "arellano", type = "HC1")))


# Modello 3: digital_payment
fe_single3 <- plm(
  old_age_saving ~ digital_payment + factor(Year),
  data = pdata,
  model = "within"
)

cat("\n====================\n")
cat("FE SINGOLO: DIGITAL PAYMENT + factor(Year)\n")
cat("====================\n")
print(summary(fe_single3))
cat("\nErrori robusti:\n")
print(coeftest(fe_single3, vcov = vcovHC(fe_single3, method = "arellano", type = "HC1")))


# Modello 4: emergency_funds
fe_single4 <- plm(
  old_age_saving ~ emergency_funds + factor(Year),
  data = pdata,
  model = "within"
)

cat("\n====================\n")
cat("FE SINGOLO: EMERGENCY FUNDS + factor(Year)\n")
cat("====================\n")
print(summary(fe_single4))
cat("\nErrori robusti:\n")
print(coeftest(fe_single4, vcov = vcovHC(fe_single4, method = "arellano", type = "HC1")))



# 28) TABELLA RIEPILOGATIVA MODELLI FE SINGOLI


riepilogo_singoli <- data.frame(
  Modello = c("formal_saving", "debit_card", "digital_payment", "emergency_funds"),
  Coefficiente = c(
    coef(fe_single1)["formal_saving"],
    coef(fe_single2)["debit_card"],
    coef(fe_single3)["digital_payment"],
    coef(fe_single4)["emergency_funds"]
  ),
  Std_Error = c(
    summary(fe_single1)$coefficients["formal_saving", "Std. Error"],
    summary(fe_single2)$coefficients["debit_card", "Std. Error"],
    summary(fe_single3)$coefficients["digital_payment", "Std. Error"],
    summary(fe_single4)$coefficients["emergency_funds", "Std. Error"]
  ),
  P_value = c(
    summary(fe_single1)$coefficients["formal_saving", "Pr(>|t|)"],
    summary(fe_single2)$coefficients["debit_card", "Pr(>|t|)"],
    summary(fe_single3)$coefficients["digital_payment", "Pr(>|t|)"],
    summary(fe_single4)$coefficients["emergency_funds", "Pr(>|t|)"]
  ),
  R2_within = c(
    summary(fe_single1)$r.squared["rsq"],
    summary(fe_single2)$r.squared["rsq"],
    summary(fe_single3)$r.squared["rsq"],
    summary(fe_single4)$r.squared["rsq"]
  )
)

cat("\n====================\n")
cat("RIEPILOGO MODELLI FE SINGOLI\n")
cat("====================\n")
print(riepilogo_singoli)



# 29) ELENCO FILE GRAFICI ESPORTATI


cat("\n====================\n")
cat("FILE GRAFICI ESPORTATI\n")
cat("====================\n")
cat("
I seguenti file PNG sono stati salvati nella cartella di lavoro:
  - fig_trend_variabili.png
  - fig_boxplot_2014_2024.png
  - fig_heatmap_2014.png
  - fig_heatmap_2024.png
  - fig_heatmap_differenza.png
  - fig_paese_*.png (uno per variabile)
  - fig_trend_paesi_selezionati.png
  - fig_diagnostica_ols.png
  - fig_cook_distance.png
Inserire in Word: Inserisci > Immagine > Da file
")

